/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package inmobiliaria;

import datasource.DataBase;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Date;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author beto
 */
public class CitaDAO implements ICitaDAO{
    private String query;
    private Connection conexion;

    @Override
    public boolean guardarDatosDeCita(Cita cita) {
        
        boolean guardadoRealizado = false;
        query = "INSERT INTO cita (lugar, fecha, mensaje, idcliente) values (?,?,?,?)";
        conexion = DataBase.getDataBaseConnection();
        
        try{
            
            PreparedStatement sentencia = conexion.prepareStatement(query);
            
            sentencia.setString(1, cita.getLugarDeCita());
            sentencia.setDate(2, (Date) cita.getFechaDeCita());
            sentencia.setString(3, cita.getMensajeDeCita());
            sentencia.setString(4, cita.getIdCliente());
            sentencia.execute();
            
            return guardadoRealizado = true;

        }
        catch(SQLException ex){
            
            Logger.getLogger(CitaDAO.class.getName()).log(Level.SEVERE, null, ex);
        
        }
        finally{
            
            DataBase.closeConnection();
            
        }
        
        return guardadoRealizado;
        
        
    }
    
}
