
package inmobiliaria;

import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public interface ICasaDAO {
    
    ArrayList<Casa> buscarCasa();
    List <Casa> buscarCasaPorPlanta(int planta);
    boolean ingresarCasa(Casa casa);
    
}
