/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package inmobiliaria;

import datasource.DataBase;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

/**
 *
 * @author beto
 */
public class BodegaDAO implements IBodegaDAO {

    private ArrayList<Bodega> bodegas;
    private String query;
    private Connection connection;
    private ResultSet result;

    public BodegaDAO() {
    }

    @Override
    public List<Bodega> buscarBodegaPorDimension(double dimension) {

        query = "select * from bodega where mConstruido = ?";
        bodegas = new ArrayList<>();
        connection = DataBase.getDataBaseConnection();
        try {
            PreparedStatement statement = connection.prepareStatement(query);
            statement.setDouble(1, dimension);
            ResultSet result = statement.executeQuery();

            while (result.next()) {
                Bodega b = new Bodega();
                b.setZonaCalle(result.getString(2));
                b.setmTotales(result.getDouble(3));
                b.setmConstruidos(result.getDouble(4));
                b.setPrecio(result.getDouble(5));
                b.setId(result.getInt(1));
                bodegas.add(b);
            }
        } catch (SQLException ex) {
            Logger.getLogger(BodegaDAO.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            DataBase.closeConnection();
        }
        return bodegas;
    }

    @Override
    public boolean registrarBodega(Bodega bodega) {
        boolean guardadoRealizado = false;
        query = "INSERT INTO bodega(ubicacion, mTotal, mConstruido, costo) values (?,?,?,?)";
        connection = DataBase.getDataBaseConnection();
        try {
            PreparedStatement sentencia = connection.prepareStatement(query);

            sentencia.setString(1, bodega.getZonaCalle());
            sentencia.setDouble(2, bodega.getmTotales());
            sentencia.setDouble(3, bodega.getmConstruidos());
            sentencia.setDouble(4, bodega.getPrecio());

            sentencia.execute();

            return guardadoRealizado = true;

        } catch (SQLException ex) {

            Logger.getLogger(BodegaDAO.class.getName()).log(Level.SEVERE, null, ex);

        } finally {

            DataBase.closeConnection();

        }

        return guardadoRealizado;

    }

    @Override
    public ArrayList<Bodega> buscarBodega() {
        bodegas = new ArrayList<>();
        query = "select * from bodega";
        connection = DataBase.getDataBaseConnection();
        try {
            PreparedStatement statement = connection.prepareStatement(query);
            result = statement.executeQuery();
            while (result.next()) {
                Bodega bod = new Bodega();
                bod.setId(result.getInt("idbodega"));
                bod.setPrecio(result.getDouble("costo"));
                bod.setZonaCalle(result.getString("ubicacion"));
                bod.setmConstruidos(result.getDouble("mConstruido"));
                bod.setmTotales(result.getDouble("mTotal"));
                bodegas.add(bod);
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Algo falló, checa que pasa en BodegaDAO");
        } finally {
            DataBase.closeConnection();
        }
        return bodegas;
    }
}
