package inmobiliaria;

import datasource.DataBase;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import javax.swing.JOptionPane;

public class Inmobiliaria {

    public static void main(String[] args) {
        DataBase.getDataBaseConnection();
        CasaDAO cd = new CasaDAO();
        ArrayList<Casa> casas = new ArrayList<Casa>();
        //casas = (ArrayList<Casa>) cd.buscarCasaPorHabitacion(0);
        if(casas.isEmpty()){
            JOptionPane.showMessageDialog(null, "No tiene nada");
        }
        Casa casa = new Casa();
        
        DataBase.closeConnection();
    }
}
