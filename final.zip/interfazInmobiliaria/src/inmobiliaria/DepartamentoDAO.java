package inmobiliaria;

import datasource.DataBase;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

public class DepartamentoDAO implements IDepartamentoDAO {

    private String query;
    private Connection connection;
    private ResultSet result;
    ArrayList<Departamento> depas;

    @Override
    public boolean registrarDepartamento(Departamento nuevo) {
        query = "insert into departamento (numeroHabitacion, ubicacion, mTotal, mConstruido, costo) values(?, ?, ?, ?, ?)";
        connection = DataBase.getDataBaseConnection();

        try {
            PreparedStatement statement = connection.prepareStatement(query);

            statement.setInt(1, nuevo.getNumeroHabitaciones());
            statement.setString(2, nuevo.getZonaCalle());
            statement.setDouble(3, nuevo.getmTotales());
            statement.setDouble(4, nuevo.getmConstruidos());
            statement.setDouble(5, nuevo.getPrecio());
            statement.execute();
        } catch (SQLException ex) {
            Logger.getLogger(DepartamentoDAO.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            DataBaseCita.closeConnection();
        }
        return false;
    }

    @Override
    public ArrayList<Departamento> buscarPorNoHabitaciones(int habitaciones) {
        ArrayList<Departamento> lista = new ArrayList<>();
        query = "select ubicacion from departamento where numeroHabitacion = ?";
        connection = DataBase.getDataBaseConnection();
        try {
            PreparedStatement statement = connection.prepareStatement(query);
            statement.setInt(1, habitaciones);
            ResultSet result = statement.executeQuery();
            while (result.next()) {
                Departamento depto = new Departamento();
                depto.setId(result.getInt("iddepartamento"));
                depto.setNumeroHabitaciones(result.getInt("numeroHabitacion"));
                depto.setZonaCalle(result.getString("ubicacion"));
                depto.setmTotales(result.getDouble("mTotal"));
                depto.setmConstruidos(result.getDouble("mConstruido"));
                depto.setPrecio(result.getDouble("costo"));
                lista.add(depto);
            }
        } catch (SQLException sql) {
            Logger.getLogger(DepartamentoDAO.class.getName()).log(Level.SEVERE, null, sql);
        } finally {
            DataBase.closeConnection();
        }

        return lista;
    }

    @Override
    public ArrayList<Departamento> buscarDepartamento() {
        depas = new ArrayList<>();
        query = "select * from departamento";
        connection = DataBase.getDataBaseConnection();
        try {
            PreparedStatement statement = connection.prepareStatement(query);
            result = statement.executeQuery();
            while (result.next()) {
                Departamento depa = new Departamento();
                depa.setId(result.getInt("iddepartamento"));
                depa.setNumeroHabitaciones(result.getInt("numeroHabitacion"));
                depa.setPrecio(result.getDouble("costo"));
                depa.setZonaCalle(result.getString("ubicacion"));
                depa.setmConstruidos(result.getDouble("mConstruido"));
                depa.setmTotales(result.getDouble("mTotal"));
                depas.add(depa);
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Algo falló, checa que pedo en CasaDAO");
        } finally {
            DataBase.closeConnection();
        }
        return depas;
    }
}
