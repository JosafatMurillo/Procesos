/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package inmobiliaria;

/**
 *
 * @author beto
 */
public class Clase {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
      
        CitaDAO cita = new CitaDAO();
        
        Cita c2 = new Cita();
        
        c2.setNombreComprador("Julio");
        c2.setNombreVendedor("German");
        c2.setIdCliente("Cas-4");
        c2.setLugarDeCita("Av.Revolucion #25");
        //c2.setFechaDeCita("06/15/2018");
        c2.setMensajeDeCita("Quiero comprar su casa");
        
        cita.guardarDatosDeCita(c2);
    }
    
}
