
package inmobiliaria;

import java.util.List;

public interface IInmobiliariaDAO {
    
    List <Casa> buscarCasaPorHabitacion(int habitacion);
    List <Casa> buscarCasaPorPlanta(int planta);
    List <Bodega> buscarBodegaPorDimension(double dimension);
    List <Oficina> buscarOficinaPorDimension(double dimension);
    List <Departamento> buscarDepaPorHabitacion(int habitacion);
    
}
