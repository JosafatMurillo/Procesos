package inmobiliaria;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.util.ArrayList;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

public class MenuPrincipal extends JFrame implements ActionListener {

    private final JButton cerrar = new JButton("Salir");
    private final JButton back = new JButton("Regresar");

    public static void main(String args[]) {
        MenuPrincipal menu = new MenuPrincipal();
        menu.MenuPrincipal();
    }

    public void MenuPrincipal() {
        iniciarComponentes();
        setTitle("Principal");
        setSize(1000, 500);
        setVisible(true);
        setLocationRelativeTo(null);
        setBackground(new Color(100,13,5));
        setDefaultCloseOperation(EXIT_ON_CLOSE);
    }

    public void iniciarComponentes() {
        JLabel presentacion = new JLabel("Seleccione un tipo de propiedad");
        JButton casa = new JButton("Casa");
        JButton oficina = new JButton("Oficina");
        JButton bodega = new JButton("Bodega");
        JButton depa = new JButton("Departamento");

        setLayout(null);

        presentacion.setBounds(450, 50, 1000, 50);
        presentacion.setVisible(true);
        bodega.setBounds(600, 150, 100, 50);
        //bodega.setVisible(true);
        depa.setBounds(600, 210, 120, 50);
        //depa.setVisible(true);
        oficina.setBounds(400, 150, 100, 50);
        //oficina.setVisible(true);
        casa.setBounds(400, 210, 100, 50);
        //casa.setVisible(true);

        cerrar.setBounds(500, 270, 100, 50);
        cerrar.setVisible(true);
        back.setBounds(500, 400, 100, 50);
        back.setVisible(true);
        add(cerrar);
        add(presentacion);

        add(casa);
        add(oficina);
        add(bodega);
        add(depa);
        cerrar.addActionListener((ActionEvent e) -> {
            dispose();
        });

        casa.addActionListener((ActionEvent e) -> {
            dispose();
            casaSelec();
        });
        oficina.addActionListener((ActionEvent e) -> {
            dispose();
            oficinas();
        });
        bodega.addActionListener((ActionEvent e) -> {
            dispose();
            bodegas();
        });
        depa.addActionListener((ActionEvent e) -> {
            dispose();
            depas();
        });
    }

    public void depas() {
        JLabel textod = new JLabel("Ingrese el numero de habitaciones");
        JButton buscard = new JButton("Buscar");
        JButton tratod = new JButton("Hacer trato");
        JTextField numerosd = new JTextField();
        JFrame hb = new JFrame("Numero habitaciones");
        hb.setSize(1000, 500);
        hb.setVisible(true);
        hb.setLocationRelativeTo(null);
        hb.setLayout(null);

        tratod.setBounds(400, 300, 100, 50);
        tratod.setVisible(true);
        buscard.setBounds(400, 200, 100, 50);
        buscard.setVisible(true);
        textod.setBounds(400, 20, 200, 50);
        textod.setVisible(true);
        numerosd.setBounds(400, 100, 100, 50);
        numerosd.setVisible(true);

        hb.add(textod);
        hb.add(buscard);
        hb.add(back);
        hb.add(tratod);
        hb.add(numerosd);
        back.addActionListener((ActionEvent e) -> {
            hb.dispose();
            MenuPrincipal();
        });

        numerosd.addKeyListener(new KeyAdapter() {
            @Override
            public void keyTyped(KeyEvent e) {
                char a = e.getKeyChar();
                if (!((int) a >= 48 && (int) a <= 57)) {
                    e.consume();
                }
            }
        });
        buscard.addActionListener((ActionEvent e) -> {

            if (!numerosd.getText().isEmpty()) {
                int nume;
                ArrayList<Departamento> depas = new ArrayList<>();
                nume = Integer.parseInt(numerosd.getText());
                InmobiliariaDAO idao = new InmobiliariaDAO();
                depas = (ArrayList<Departamento>) idao.buscarDepaPorHabitacion(nume);
                if (depas.isEmpty()) {
                    JOptionPane.showMessageDialog(null, "No tenemos propiedades con estas caracteristicas");
                } else {
                    hb.dispose();
                    listarDepas(depas);
                }
            } else {
                JOptionPane.showMessageDialog(null, "No puedes dejar el campo vacio");
            }
        });
        tratod.addActionListener((ActionEvent e) -> {
            hb.dispose();
            tratar();
        });
    }

    public void oficinas() {
        JLabel textoo = new JLabel("Ingrese tamaño del local");
        JButton buscaro = new JButton("Buscar");
        JButton tratoo = new JButton("Hacer trato");
        JTextField numeroso = new JTextField();
        JFrame to = new JFrame("Tamaño");
        to.setSize(1000, 500);
        to.setVisible(true);
        to.setLocationRelativeTo(null);
        to.setLayout(null);

        tratoo.setBounds(400, 300, 100, 50);
        tratoo.setVisible(true);
        buscaro.setBounds(400, 200, 100, 50);
        buscaro.setVisible(true);
        textoo.setBounds(400, 20, 200, 50);
        textoo.setVisible(true);
        numeroso.setBounds(400, 100, 100, 50);
        numeroso.setVisible(true);

        to.add(textoo);
        to.add(buscaro);
        to.add(back);
        to.add(tratoo);
        to.add(numeroso);
        back.addActionListener((ActionEvent e) -> {
            to.dispose();
            MenuPrincipal();
        });

        numeroso.addKeyListener(new KeyAdapter() {
            @Override
            public void keyTyped(KeyEvent e) {
                char a = e.getKeyChar();
                if (!((int) a >= 48 && (int) a <= 57)) {
                    e.consume();
                }
            }
        });

        buscaro.addActionListener((ActionEvent e) -> {

            if (!numeroso.getText().isEmpty()) {
                double nume;
                ArrayList<Oficina> oficinas = new ArrayList<>();
                nume = Double.parseDouble(numeroso.getText());
                InmobiliariaDAO idao = new InmobiliariaDAO();
                oficinas = (ArrayList<Oficina>) idao.buscarOficinaPorDimension(nume);
                if (oficinas.isEmpty()) {
                    JOptionPane.showMessageDialog(null, "No tenemos propiedades con estas caracteristicas");
                } else {
                    to.dispose();
                    listarOficinas(oficinas);
                }
            } else {
                JOptionPane.showMessageDialog(null, "No puedes dejar el campo vacio");
            }
        });
        tratoo.addActionListener((ActionEvent e) -> {
            to.dispose();
            tratar();
        });
    }

    public void bodegas() {
        JLabel textob = new JLabel("Ingrese tamaño del local");
        JButton buscarb = new JButton("Buscar");
        JButton tratob = new JButton("Hacer trato");
        JTextField numerosb = new JTextField();
        JFrame tb = new JFrame("Tamaño");
        tb.setSize(1000, 500);
        tb.setVisible(true);
        tb.setLocationRelativeTo(null);
        tb.setLayout(null);

        tratob.setBounds(400, 300, 100, 50);
        tratob.setVisible(true);
        buscarb.setBounds(400, 200, 100, 50);
        buscarb.setVisible(true);
        textob.setBounds(400, 20, 200, 50);
        textob.setVisible(true);
        numerosb.setBounds(400, 100, 100, 50);
        numerosb.setVisible(true);

        tb.add(textob);
        tb.add(buscarb);
        tb.add(back);
        tb.add(tratob);
        tb.add(numerosb);

        numerosb.addKeyListener(new KeyAdapter() {
            @Override
            public void keyTyped(KeyEvent e) {
                char a = e.getKeyChar();
                if (!((int) a >= 48 && (int) a <= 57)) {
                    e.consume();
                }
            }
        });
        back.addActionListener((ActionEvent e) -> {
            tb.dispose();
            MenuPrincipal();
        });
        buscarb.addActionListener((ActionEvent e) -> {
            if (!numerosb.getText().isEmpty()) {
                double nume;
                ArrayList<Bodega> bodegas = new ArrayList<>();
                nume = Double.parseDouble(numerosb.getText());
                InmobiliariaDAO idao = new InmobiliariaDAO();
                bodegas = (ArrayList<Bodega>) idao.buscarBodegaPorDimension(nume);
                if (bodegas.isEmpty()) {
                    JOptionPane.showMessageDialog(null, "No tenemos propiedades con estas caracteristicas");
                } else {
                    tb.dispose();
                    listarBodegas(bodegas);
                }
            } else {
                JOptionPane.showMessageDialog(null, "No puedes dejar el campo vacio");
            }
        });
        tratob.addActionListener((ActionEvent e) -> {
            tb.dispose();
            tratar();
        });
    }

    public void casaSelec() {
        JLabel centro = new JLabel("Seleccione tipo de filtrado");
        JButton habitacion = new JButton("Numero de Habitaciones");
        JButton planta = new JButton("Numero de Plantas");
        JFrame casaS = new JFrame("Seleccion de filtrado");

        habitacion.setBounds(400, 150, 200, 50);
        habitacion.setVisible(true);
        planta.setBounds(400, 210, 200, 50);
        planta.setVisible(true);
        centro.setBounds(450, 50, 200, 50);
        centro.setVisible(true);

        back.setBounds(750, 400, 100, 50);
        back.setVisible(true);

        casaS.setSize(1000, 500);
        casaS.setVisible(true);
        casaS.setLocationRelativeTo(null);
        casaS.setLayout(null);
        casaS.add(back);
        casaS.add(habitacion);
        casaS.add(planta);
        casaS.add(centro);
        back.addActionListener((ActionEvent e) -> {
            casaS.dispose();
            MenuPrincipal();
        });
        habitacion.addActionListener((ActionEvent e) -> {
            casaS.dispose();
            habitaciones();
        });
        planta.addActionListener((ActionEvent e) -> {
            casaS.dispose();
            plantas();
        });
    }

    public void habitaciones() {
        JLabel texto = new JLabel("Ingrese el numero de habitaciones");
        JButton buscar = new JButton("Buscar");
        JButton trato = new JButton("Hacer trato");
        JTextField numeros = new JTextField();
        JFrame habitacion = new JFrame("Numero habitaciones");
        habitacion.setSize(1000, 500);
        habitacion.setVisible(true);
        habitacion.setLocationRelativeTo(null);
        habitacion.setLayout(null);

        trato.setBounds(400, 300, 100, 50);
        buscar.setBounds(400, 200, 100, 50);
        buscar.setVisible(true);
        texto.setBounds(400, 20, 200, 50);
        texto.setVisible(true);
        numeros.setBounds(400, 100, 100, 50);
        numeros.setVisible(true);

        habitacion.add(texto);
        habitacion.add(buscar);
        habitacion.add(back);
        habitacion.add(numeros);
        habitacion.add(trato);
        back.addActionListener((ActionEvent e) -> {
            habitacion.dispose();
            MenuPrincipal();
        });
        numeros.addKeyListener(new KeyAdapter() {
            @Override
            public void keyTyped(KeyEvent e) {
                char a = e.getKeyChar();
                if (!((int) a >= 48 && (int) a <= 57)) {
                    e.consume();
                }
            }
        });

        buscar.addActionListener((ActionEvent e) -> {
            if (!numeros.getText().isEmpty()) {
                int nume;
                ArrayList<Casa> casas = new ArrayList<>();
                nume = Integer.parseInt(numeros.getText());
                InmobiliariaDAO idao = new InmobiliariaDAO();
                casas = (ArrayList<Casa>) idao.buscarCasaPorHabitacion(nume);
                if (casas.isEmpty()) {
                    JOptionPane.showMessageDialog(null, "No tenemos propiedades con estas caracteristicas");
                } else {
                    habitacion.dispose();
                    listarCasas(casas);
                }
            } else {
                JOptionPane.showMessageDialog(null, "No puedes dejar el campo vacio");
            }
        });
        trato.addActionListener((ActionEvent e) -> {
            habitacion.dispose();
            tratar();
        });
    }

    public void listarCasas(ArrayList<Casa> casas) {
        JFrame ch = new JFrame("Lista de casas");
        JButton trato = new JButton("Hacer trato");
        int i = 50;
        ch.setSize(1000, 500);
        ch.setVisible(true);
        ch.setLocationRelativeTo(null);
        ch.setLayout(null);
        ch.add(trato);
        for (int j = 0; j < casas.size(); j++) {
            JLabel cosas = new JLabel("Precio de la propiedad: " + casas.get(j).getPrecio()+"-->"
                    +"ID casa: " + casas.get(j).getId()+ "-->"
//                    +"Zona: " + casas.get(j).getZona() + "-->"
                    + "Numero de plantas: " + casas.get(j).getNumeroPlantas() + "-->"
                    + "Numero de habitaciones: " + casas.get(j).getNumeroHabitaciones() + "-->"
                    + "Dimensiones de la propiedad: " + casas.get(j).getmTotales());
            cosas.setBounds(10, i, 1500, 50);
            cosas.setVisible(true);
            ch.add(cosas);
            i = i + 60;
        }
        trato.setBounds(400, i + 60, 100, 50);
        trato.addActionListener((ActionEvent e) -> {
            ch.dispose();
            tratar();
        });
    }

    public void listarOficinas(ArrayList<Oficina> oficinas) {
        int i = 50;
        JFrame cho = new JFrame("Lista de oficinas");
        JButton trat = new JButton("Hacer trato");
        cho.setSize(1000, 500);
        cho.setVisible(true);
        cho.setLocationRelativeTo(null);
        cho.setLayout(null);
        cho.add(trat);
        for (int j = 0; j < oficinas.size(); j++) {
            JLabel cosas = new JLabel("Precio de la propiedad: " + oficinas.get(j).getPrecio() + "; "
//                    + "Zona: " + oficinas.get(j).getZona() + "; "
                    + "Dimensiones de la propiedad: " + oficinas.get(j).getmTotales());
            cosas.setBounds(10, i, 900, 50);
            cosas.setVisible(true);
            cho.add(cosas);
            i = i + 60;
        }
        trat.setBounds(400, i, 100, 50);
        trat.addActionListener((ActionEvent e) -> {
            cho.dispose();
            tratar();
        });
    }

    public void listarBodegas(ArrayList<Bodega> bodegas) {
        int i = 50;
        JFrame chb = new JFrame("Lista de bodegas");
        JButton tra = new JButton("Hacer trato");
        chb.setSize(1000, 500);
        chb.setVisible(true);
        chb.setLocationRelativeTo(null);
        chb.setLayout(null);
        chb.add(tra);
        for (int j = 0; j < bodegas.size(); j++) {
            JLabel cosas = new JLabel("Precio de la propiedad: " + bodegas.get(j).getPrecio() + "; "
//                    + "Zona: " + bodegas.get(j).getZona() + "; "
                    + "Dimensiones de la propiedad: " + bodegas.get(j).getmTotales());
            cosas.setBounds(10, i, 900, 50);
            cosas.setVisible(true);
            chb.add(cosas);
            i = i + 60;
        }
        tra.setBounds(400, i, 100, 50);
        tra.addActionListener((ActionEvent e) -> {
            chb.dispose();
            tratar();
        });
    }

    public void listarDepas(ArrayList<Departamento> depas) {
        int i = 50;
        JFrame chd = new JFrame("Lista de departamentos");
        JButton rege = new JButton("Hacer trato");
        chd.setSize(1000, 500);
        chd.setVisible(true);
        chd.setLocationRelativeTo(null);
        chd.setLayout(null);
        chd.add(rege);
        for (int j = 0; j < depas.size(); j++) {
            JLabel cosas = new JLabel("Precio de la propiedad: " + depas.get(j).getPrecio() + "; "
//                    + "Zona: " + depas.get(j).getZona() + "; "
                    + "Numero de habitaciones: " + depas.get(j).getNumeroHabitaciones() + "; "
                    + "Dimensiones de la propiedad: " + depas.get(j).getmTotales());
            cosas.setBounds(10, i, 900, 50);
            cosas.setVisible(true);
            chd.add(cosas);
            i = i + 60;
        }

        rege.setBounds(400, i, 100, 50);
        chd.add(rege);
        rege.addActionListener((ActionEvent e) -> {
            chd.dispose();
            tratar();
        });
    }

    public void plantas() {
        JLabel texto = new JLabel("Ingrese el numero de plantas");
        JButton buscar = new JButton("Buscar");
        JButton trato = new JButton("Hacer trato");
        JTextField numeros = new JTextField();
        JFrame planta = new JFrame("Numero plantas");
        planta.setSize(1000, 500);
        planta.setVisible(true);
        planta.setLocationRelativeTo(null);
        planta.setLayout(null);

        trato.setBounds(400, 300, 100, 50);
        trato.setVisible(true);
        buscar.setBounds(400, 200, 100, 50);
        buscar.setVisible(true);
        texto.setBounds(400, 20, 200, 50);
        texto.setVisible(true);
        numeros.setBounds(400, 100, 100, 50);
        numeros.setVisible(true);

        planta.add(texto);
        planta.add(buscar);
        planta.add(back);
        planta.add(trato);
        planta.add(numeros);
        back.addActionListener((ActionEvent e) -> {
            planta.dispose();
            MenuPrincipal();
        });

        numeros.addKeyListener(new KeyAdapter() {
            @Override
            public void keyTyped(KeyEvent e) {
                char a = e.getKeyChar();
                if (!((int) a >= 48 && (int) a <= 57)) {
                    e.consume();
                }
            }
        });

        buscar.addActionListener((ActionEvent e) -> {
            if (!numeros.getText().isEmpty()) {
                int nume;
                ArrayList<Casa> casas = new ArrayList<>();
                nume = Integer.parseInt(numeros.getText());
                InmobiliariaDAO idao = new InmobiliariaDAO();
                casas = (ArrayList<Casa>) idao.buscarCasaPorPlanta(nume);
                if (casas.isEmpty()) {
                    JOptionPane.showMessageDialog(null, "No tenemos propiedades con estas caracteristicas");
                } else {
                    planta.dispose();
                    listarCasas(casas);
                }
            } else {
                JOptionPane.showMessageDialog(null, "No puedes dejar el campo vacio");
            }
        });
        trato.addActionListener((ActionEvent e) -> {
            planta.dispose();
            tratar();
        });
    }

    public void tratar() {
        JButton reg = new JButton("Regresar");
        JButton guardar = new JButton("Guardar");
        JFrame marcoT = new JFrame("Trato");
        JLabel ven = new JLabel("Vendedor");
        JLabel com = new JLabel("Comprador");
        JLabel lug = new JLabel("Lugar");
        JLabel fec = new JLabel("Fecha");
        JLabel cita = new JLabel("Mensaje");
        JLabel id = new JLabel("ID Propieedad");
        JTextField citam = new JTextField();
        JTextField vend = new JTextField();
        JTextField comp = new JTextField();
        JTextField luga = new JTextField();
        JTextField fech = new JTextField();
        JTextField idt = new JTextField();

        marcoT.setSize(1000, 500);
        marcoT.setVisible(true);
        marcoT.setLocationRelativeTo(null);
        marcoT.setVisible(true);
        marcoT.setLayout(null);

        ven.setBounds(10, 10, 200, 50);
        com.setBounds(10, 70, 200, 50);
        lug.setBounds(10, 130, 200, 50);
        fec.setBounds(10, 190, 200, 50);
        cita.setBounds(10, 250, 200, 50);
        id.setBounds(10, 310, 200, 50);
        vend.setBounds(300, 10, 200, 50);
        comp.setBounds(300, 70, 200, 50);
        luga.setBounds(300, 130, 200, 50);
        fech.setBounds(300, 190, 200, 50);
        citam.setBounds(300, 250, 200, 50);
        idt.setBounds(300, 310, 200, 50);
        cerrar.setBounds(350, 400, 100, 50);
        reg.setBounds(450, 400, 100, 50);
        guardar.setBounds(250, 400, 100, 50);
        reg.setVisible(true);

        marcoT.add(cerrar);
        marcoT.add(reg);
        marcoT.add(ven);
        marcoT.add(com);
        marcoT.add(lug);
        marcoT.add(fec);
        marcoT.add(id);
        marcoT.add(cita);
        marcoT.add(vend);
        marcoT.add(comp);
        marcoT.add(luga);
        marcoT.add(fech);
        marcoT.add(citam);
        marcoT.add(idt);
        marcoT.add(guardar);

        cerrar.addActionListener((ActionEvent e) -> {
            marcoT.dispose();
        });
        reg.addActionListener((ActionEvent e) -> {
            marcoT.dispose();
            MenuPrincipal();
        });
        guardar.addActionListener((ActionEvent e) -> {
            if (citam.getText().isEmpty() || idt.getText().isEmpty() || fech.getText().isEmpty()
                    || luga.getText().isEmpty() || comp.getText().isEmpty() || vend.getText().isEmpty()) {
                JOptionPane.showMessageDialog(null, "No puedes dejar ningun campo vacio prro");
            } else {
                Cita citas = new Cita();
                CitaDAO cit = new CitaDAO();
                String nombreV = vend.getText(), nombreC = comp.getText(), lugar = luga.getText(),
                        mensaje = citam.getText(), fecha = fech.getText(), idP = idt.getText();
                citas.setNombreComprador(nombreC);
                citas.setNombreVendedor(nombreV);
                //citas.setFechaDeCita(fecha);
                citas.setIdCliente(idP);
                citas.setLugarDeCita(lugar);
                citas.setMensajeDeCita(mensaje);
                cit.guardarDatosDeCita(citas);
                vend.setText("");
                comp.setText("");
                luga.setText("");
                citam.setText("");
                fech.setText("");
                idt.setText("");
                JOptionPane.showMessageDialog(null, "Guardado exitoso");
            }
        });
    }

    @Override
    public void actionPerformed(ActionEvent ae) {
        System.out.println("Algo pasa");
    }

}
