
package inmobiliaria;

public class Propiedad {
    
    private double precio;
    private int id;
    private String zonaCalle;
    int numero;
    private double mTotales;
    private double mConstruidos;
    int numeroBaños;

    public int getNumeroBaños() {
        return numeroBaños;
    }

    public void setNumeroBaños(int numeroBaños) {
        this.numeroBaños = numeroBaños;
    }

    
    public Propiedad() {
    }

    public double getPrecio() {
        return precio;
    }

    public void setPrecio(double precio) {
        this.precio = precio;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getZonaCalle() {
        return zonaCalle;
    }

    public void setZonaCalle(String zonaCalle) {
        this.zonaCalle = zonaCalle;
    }

    public int getNumero() {
        return numero;
    }

    public void setNumero(int numero) {
        this.numero = numero;
    }

    public double getmTotales() {
        return mTotales;
    }

    public void setmTotales(double mTotales) {
        this.mTotales = mTotales;
    }

    public double getmConstruidos() {
        return mConstruidos;
    }

    public void setmConstruidos(double mConstruidos) {
        this.mConstruidos = mConstruidos;
    }

    
}
