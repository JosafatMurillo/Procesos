/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package inmobiliaria;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author beto
 */
public interface IOficinaDAO {
    
    List <Oficina> buscarOficinaPorDimension(double dimension);
    boolean registrarBodega(Oficina oficina);
    ArrayList<Oficina> buscarOficinas();
    
}