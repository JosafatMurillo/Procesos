package inmobiliaria;

import java.util.ArrayList;

public interface IDepartamentoDAO {
    
    boolean registrarDepartamento(Departamento nuevo);
    
    ArrayList<Departamento> buscarPorNoHabitaciones(int habitaciones);
    ArrayList<Departamento> buscarDepartamento();
}
