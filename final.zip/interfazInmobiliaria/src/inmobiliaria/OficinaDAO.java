/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package inmobiliaria;

import datasource.DataBase;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

/**
 *
 * @author beto
 */
public class OficinaDAO implements IOficinaDAO {

    private ArrayList<Oficina> oficinas;
    private String query;
    private Connection connection;
    private ResultSet result;

    public OficinaDAO() {
    }

    @Override
    public List<Oficina> buscarOficinaPorDimension(double dimension) {
        oficinas = new ArrayList<>();
        connection = DataBase.getDataBaseConnection();
        query = "select * from oficina where mConstruido = ?";
        try {
            PreparedStatement statement = connection.prepareStatement(query);
            statement.setDouble(1, dimension);
            ResultSet result = statement.executeQuery();

            while (result.next()) {
                Oficina o = new Oficina();
                o.setZonaCalle(result.getString(2));
                o.setmTotales(result.getDouble(3));
                o.setmConstruidos(result.getDouble(4));
                o.setPrecio(result.getDouble(5));
                o.setId(result.getInt(1));
                oficinas.add(o);
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Ingreso algo raro");
            Logger.getLogger(OficinaDAO.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            DataBase.closeConnection();
        }
        return oficinas;
    }

    @Override
    public boolean registrarBodega(Oficina oficina) {
        boolean guardadoRealizado = false;
        connection = DataBase.getDataBaseConnection();
        query = "INSERT INTO oficina(ubicacion, mTotal, mConstruido, costo) values (?,?,?,?)";
        try {
            PreparedStatement sentencia = connection.prepareStatement(query);

            sentencia.setString(1, oficina.getZonaCalle());
            sentencia.setDouble(2, oficina.getmTotales());
            sentencia.setDouble(3, oficina.getmConstruidos());
            sentencia.setDouble(4, oficina.getPrecio());
            sentencia.execute();

            return guardadoRealizado = true;

        } catch (SQLException ex) {

            Logger.getLogger(OficinaDAO.class.getName()).log(Level.SEVERE, null, ex);

        } finally {

            DataBase.closeConnection();

        }

        return guardadoRealizado;

    }

    @Override
    public ArrayList<Oficina> buscarOficinas() {
        oficinas = new ArrayList<>();
        query = "select * from oficina";
        connection = DataBase.getDataBaseConnection();
        try {
            PreparedStatement statement = connection.prepareStatement(query);
            result = statement.executeQuery();
            while (result.next()) {
                Oficina ofi = new Oficina();
                ofi.setId(result.getInt("idoficina"));
                ofi.setPrecio(result.getDouble("costo"));
                ofi.setZonaCalle(result.getString("ubicacion"));
                ofi.setmConstruidos(result.getDouble("mConstruido"));
                ofi.setmTotales(result.getDouble("mTotal"));
                oficinas.add(ofi);
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Algo falló, checa que pasa en OficinaDAO");
        } finally {
            DataBase.closeConnection();
        }
        return oficinas;
    }

}
