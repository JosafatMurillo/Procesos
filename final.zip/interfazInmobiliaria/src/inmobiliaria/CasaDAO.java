package inmobiliaria;

import datasource.DataBase;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;

public class CasaDAO implements ICasaDAO {
    
    private ArrayList<Casa> casas;
    private Connection connection;
    private String query;
    private ResultSet result;
    
    @Override
    public ArrayList buscarCasa() {
        casas = new ArrayList<>();
        query = "select * from casa";
        connection = DataBase.getDataBaseConnection();
        try {
            PreparedStatement statement = connection.prepareStatement(query);
            result = statement.executeQuery();
            while (result.next()) {
                Casa casa = new Casa();
                if (result.getInt("cochera") == 0) {
                    casa.setCochera(false);
                } else {
                    casa.setCochera(true);
                }
                casa.setId(result.getInt("idcasa"));
                casa.setNumeroCoches(result.getInt("numeroCoches"));
                casa.setNumeroHabitaciones(result.getInt("numeroHabitacion"));
                casa.setNumeroPlantas(result.getInt("numeroPlantas"));
                casa.setPrecio(result.getDouble("costo"));
                casa.setZonaCalle(result.getString("ubicacion"));
                casa.setmConstruidos(result.getDouble("mConstruido"));
                casa.setmTotales(result.getDouble("mTotal"));
                casas.add(casa);
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Algo falló, checa que pedo en CasaDAO");
        } finally {
            DataBase.closeConnection();
        }
        return casas;
    }
    
    @Override
    public List<Casa> buscarCasaPorPlanta(int planta) {
        casas = new ArrayList<>();
        query = "select * from casa where numeroPlantas = ?";
        connection = DataBase.getDataBaseConnection();
        try {
            PreparedStatement statement = connection.prepareStatement(query);
            statement.setInt(1, planta);
            ResultSet result = statement.executeQuery();
            while (result.next()) {
                Casa casa = new Casa();
                if (result.getInt("cochera") == 0) {
                    casa.setCochera(false);
                } else {
                    casa.setCochera(true);
                }
                casa.setId(result.getInt("idcasa"));
                casa.setNumeroCoches(result.getInt("numeroCoches"));
                casa.setNumeroHabitaciones(result.getInt("numeroHabitacion"));
                casa.setNumeroPlantas(result.getInt("numeroPlantas"));
                casa.setPrecio(result.getDouble("costo"));
                casa.setZonaCalle(result.getString("ubicacion"));
                casa.setmConstruidos(result.getDouble("mConstruido"));
                casa.setmTotales(result.getDouble("mTotal"));
                casas.add(casa);
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Algo falló, checa que pedo en CasaDAO");
        } finally {
            DataBase.closeConnection();
        }
        return casas;
    }
    
    @Override
    public boolean ingresarCasa(Casa casa) {
        boolean checador = false;
        casas = new ArrayList<>();
        query = "insert into casa (numeroHabitacion, numeroPlantas, cochera, numeroCoches, ubicacion, mTotal, mConstruido,"
                + " costo) values (?, ?, ?, ?, ?, ?, ?, ?)";
        connection = DataBase.getDataBaseConnection();
        try {
            PreparedStatement statement = connection.prepareStatement(query);
            statement.setInt(1, casa.getNumeroHabitaciones());
            statement.setInt(2, casa.getNumeroPlantas());
            if (casa.isCochera() == true) {
                statement.setInt(3, 1);
            } else {
                statement.setInt(3, 0);
            }
            statement.setInt(4, casa.getNumeroCoches());
            statement.setString(5, casa.getZonaCalle());
            statement.setDouble(6, casa.getmTotales());
            statement.setDouble(7, casa.getmConstruidos());
            statement.setDouble(8, casa.getPrecio());
            statement.execute();
            checador = true;
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Algo falló, checa que pedo en CasaDAO");
        } finally {
            DataBase.closeConnection();
        }
        return checador;
    }
}
