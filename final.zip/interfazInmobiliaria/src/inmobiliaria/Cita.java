/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package inmobiliaria;

import java.util.Date;

/**
 *
 * @author beto
 */
public class Cita {
    
    private String nombreComprador;
    private String nombreVendedor;
    private String idCliente;
    private String lugarDeCita;
    private Date fechaDeCita;
    private String mensajeDeCita;
    
    public Cita() {
        
    }

    public String getNombreComprador() {
        return nombreComprador;
    }

    public void setNombreComprador(String nombreComprador) {
        this.nombreComprador = nombreComprador;
    }

    public String getNombreVendedor() {
        return nombreVendedor;
    }

    public void setNombreVendedor(String nombreVendedor) {
        this.nombreVendedor = nombreVendedor;
    }

    public String getIdCliente() {
        return idCliente;
    }

    public void setIdCliente(String idCliente) {
        this.idCliente = idCliente;
    }

    public String getLugarDeCita() {
        return lugarDeCita;
    }

    public void setLugarDeCita(String lugarDeCita) {
        this.lugarDeCita = lugarDeCita;
    }

    public Date getFechaDeCita() {
        return fechaDeCita;
    }

    public void setFechaDeCita(Date fechaDeCita) {
        this.fechaDeCita = fechaDeCita;
    }

    public String getMensajeDeCita() {
        return mensajeDeCita;
    }

    public void setMensajeDeCita(String mensajeDeCita) {
        this.mensajeDeCita = mensajeDeCita;
    }
}
