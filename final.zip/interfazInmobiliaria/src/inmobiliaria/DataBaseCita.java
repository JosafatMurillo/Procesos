
package inmobiliaria;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

class DataBaseCita {
    private static Connection connection;    
    
    private static void makeConnection(){
        try {
            
            String url= "jdbc:mysql://localhost:3306/inmobiliaria";
            String userName = "beto";
            String password = "123";
            connection = (Connection)DriverManager.getConnection(url,userName,password);
        } catch (SQLException ex) {
            java.util.logging.Logger.getLogger(DataBaseCita.class.getName()).log(Level.SEVERE, null, ex);
        } 
    }
    public static Connection getDataBaseConnection() {        
        makeConnection();
        return DataBaseCita.connection;
 
    }
    
    public static void closeConnection(){
        if(connection!=null){
            try {
                if(!connection.isClosed()){
                    connection.close();                
                }
            } catch (SQLException ex) {
                Logger.getLogger(DataBaseCita.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }
}
