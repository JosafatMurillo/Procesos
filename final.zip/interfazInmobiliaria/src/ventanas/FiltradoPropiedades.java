/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ventanas;

import inmobiliaria.Casa;
import inmobiliaria.Departamento;
import inmobiliaria.Oficina;
import inmobiliaria.Bodega;
import java.util.List;
import javax.swing.JOptionPane;

/**
 *
 * @author BODEGA
 */
public class FiltradoPropiedades {

    FiltradoPropiedades(List<Casa> casa, boolean g) {
        if (casa.isEmpty()) {
            JOptionPane.showMessageDialog(null, "No se encontro ninguna propiedad con esa caracteristica");
            Principal p = new Principal();
            p.setVisible(true);
        } else {
            int i = 0;
            while (i < casa.size()) {
                JOptionPane.showConfirmDialog(null, casa.get(i).getNumeroHabitaciones() + " " + casa.get(i).getZonaCalle()+ " "
                        + casa.get(i).getNumeroPlantas() + " " + casa.get(i).getPrecio() + " " + casa.get(i).getNumeroCoches() + "\n");
                i++;
            }
            Trato t = new Trato(i);
            t.setVisible(true);
        }
    }

    FiltradoPropiedades(List<Departamento> depa, int i) {
        if (depa.isEmpty()) {
            JOptionPane.showMessageDialog(null, "No se encontro ninguna propiedad con esa caracteristica");
            Principal p = new Principal();
            p.setVisible(true);
        } else {
            i = 0;
            while (i < depa.size()) {
                JOptionPane.showConfirmDialog(null, depa.get(i).getNumeroHabitaciones() + " " + depa.get(i).getZonaCalle() + " "
                        + depa.get(i).getPrecio() + "\n");
                i++;
            }
            Trato t = new Trato(i);
            t.setVisible(true);
        }
    }

    FiltradoPropiedades(List<Oficina> ofi, char h) {
        if (ofi.isEmpty()) {
            JOptionPane.showMessageDialog(null, "No se encontro ninguna propiedad con esa caracteristica");
            Principal p = new Principal();
            p.setVisible(true);
        } else {
            int i = 0;
            while (i < ofi.size()) {
                JOptionPane.showConfirmDialog(null, ofi.get(i).getZonaCalle() + " "
                        + ofi.get(i).getPrecio() + "\n");
                i++;
            }
            Trato t = new Trato(i);
            t.setVisible(true);
        }
    }

    FiltradoPropiedades(List<Bodega> bode) {
        if (bode.isEmpty()) {
            JOptionPane.showMessageDialog(null, "No se encontro ninguna propiedad con esa caracteristica");
            Principal p = new Principal();
            p.setVisible(true);
        } else {
            int i = 0;
            while (i < bode.size()) {
                JOptionPane.showConfirmDialog(null, bode.get(i).getZonaCalle() + " "
                        + bode.get(i).getPrecio() + "\n");
                i++;
            }
            Trato t = new Trato(i);
            t.setVisible(true);
        }
    }
}
