/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ventanas;

import inmobiliaria.Bodega;
import inmobiliaria.BodegaDAO;
import inmobiliaria.CasaDAO;
import inmobiliaria.Casa;
import inmobiliaria.Departamento;
import inmobiliaria.DepartamentoDAO;
import inmobiliaria.Oficina;
import inmobiliaria.OficinaDAO;
import java.util.ArrayList;

/**
 *
 * @author AngelD
 */
public class ListarPropiedades extends javax.swing.JFrame {

    ArrayList<Casa> casas;
    ArrayList<Departamento> depas;
    ArrayList<Oficina> oficinas;
    ArrayList<Bodega> bodegas;
    
    /**
     * Creates new form BuscaCasas
     */
    public ListarPropiedades() {
        initComponents();
        btnTrato.setVisible(false);
    }

    ListarPropiedades(int a) {
        initComponents();
        btnTrato.setVisible(false);
        casas();
    }

    ListarPropiedades(boolean c) {
        initComponents();
        btnTrato.setVisible(false);
        depas();
    }

    ListarPropiedades(double d) {
        initComponents();
        btnTrato.setVisible(false);
        oficinas();
    }

    ListarPropiedades(String b) {
        initComponents();
        btnTrato.setVisible(false);
        bodegas();
    }
    
    public void depas(){
        DepartamentoDAO depaDao = new DepartamentoDAO();
        depas = depaDao.buscarDepartamento();
        mostrarDepas();
    }
    
    public void oficinas(){
        OficinaDAO oficinaDao = new OficinaDAO();
        oficinas = oficinaDao.buscarOficinas();
        mostrarOficinas();
    }
    
    public void bodegas(){
        BodegaDAO bodegaDao = new BodegaDAO();
        bodegas = bodegaDao.buscarBodega();
        mostrarBodegas();
    }

    public void casas() {
        CasaDAO house = new CasaDAO();
        casas = house.buscarCasa();
        mostrarCasas();
    }

    public void mostrarCasas() {
        String matriz[][] = new String[casas.size()][8];
        for (int i = 0; i < casas.size(); i++) {
            matriz[i][0] = casas.get(i).getZonaCalle();
            matriz[i][1] = String.valueOf(casas.get(i).getNumeroHabitaciones());
            matriz[i][2] = String.valueOf(casas.get(i).getNumeroPlantas());
            matriz[i][3] = String.valueOf(casas.get(i).getmTotales());
            matriz[i][4] = String.valueOf(casas.get(i).getmConstruidos());
            if (casas.get(i).isCochera() == true) {
                matriz[i][5] = "Sí";
            } else {
                matriz[i][5] = "No";
            }
            matriz[i][6] = String.valueOf(casas.get(i).getNumeroCoches());
            matriz[i][7] = String.valueOf(casas.get(i).getPrecio());
        }

        jtPropiedades.setModel(new javax.swing.table.DefaultTableModel(
                matriz,
                new String[]{
                    "Ubicación", "Número de habitaciones", "Número de plantas", "Metros cuadrados", "Metros construidos", "Cochera", "Capaciad de cochera", "Precio"
                }
        ));
    }
    
    public void mostrarDepas() {
        String matriz[][] = new String[depas.size()][5];
        for (int i = 0; i < depas.size(); i++) {
            matriz[i][0] = depas.get(i).getZonaCalle();
            matriz[i][1] = String.valueOf(depas.get(i).getNumeroHabitaciones());
            matriz[i][2] = String.valueOf(depas.get(i).getmTotales());
            matriz[i][3] = String.valueOf(depas.get(i).getmConstruidos());
            matriz[i][4] = String.valueOf(depas.get(i).getPrecio());
        }

        jtPropiedades.setModel(new javax.swing.table.DefaultTableModel(
                matriz,
                new String[]{
                    "Ubicación", "Número de habitaciones", "Metros cuadrados", "Metros construidos", "Precio"
                }
        ));
    }
    
    public void mostrarBodegas() {
        String matriz[][] = new String[bodegas.size()][4];
        for (int i = 0; i < bodegas.size(); i++) {
            matriz[i][0] = bodegas.get(i).getZonaCalle();
            matriz[i][1] = String.valueOf(bodegas.get(i).getmTotales());
            matriz[i][2] = String.valueOf(bodegas.get(i).getmConstruidos());
            matriz[i][3] = String.valueOf(bodegas.get(i).getPrecio());
        }

        jtPropiedades.setModel(new javax.swing.table.DefaultTableModel(
                matriz,
                new String[]{
                    "Ubicación", "Metros cuadrados", "Metros construidos", "Precio"
                }
        ));
    }

    public void mostrarOficinas() {
        String matriz[][] = new String[oficinas.size()][4];
        for (int i = 0; i < oficinas.size(); i++) {
            matriz[i][0] = oficinas.get(i).getZonaCalle();
            matriz[i][1] = String.valueOf(oficinas.get(i).getmTotales());
            matriz[i][2] = String.valueOf(oficinas.get(i).getmConstruidos());
            matriz[i][3] = String.valueOf(oficinas.get(i).getPrecio());
        }

        jtPropiedades.setModel(new javax.swing.table.DefaultTableModel(
                matriz,
                new String[]{
                    "Ubicación", "Metros cuadrados", "Metros construidos", "Precio"
                }
        ));
    }
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        jtPropiedades = new javax.swing.JTable();
        btnRegresar = new javax.swing.JButton();
        btnTrato = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jtPropiedades.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null}
            },
            new String [] {
                "Ubicación", "Número de habitaciones", "Número de plantas", "Metros cuadrados", "Metros construidos", "Cochera", "Capaciad de cochera", "Precio"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jtPropiedades.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jtPropiedadesMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(jtPropiedades);

        btnRegresar.setText("Regresar");
        btnRegresar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnRegresarActionPerformed(evt);
            }
        });

        btnTrato.setText("Hacer trato");
        btnTrato.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnTratoActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 740, Short.MAX_VALUE)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(btnRegresar)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(btnTrato)))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 271, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 33, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnRegresar)
                    .addComponent(btnTrato))
                .addContainerGap())
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void btnRegresarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnRegresarActionPerformed
        InterfazInmobiliaria inmo = new InterfazInmobiliaria();
        inmo.setVisible(rootPaneCheckingEnabled);
        dispose();
    }//GEN-LAST:event_btnRegresarActionPerformed

    private void btnTratoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnTratoActionPerformed
        Trato t = new Trato(jtPropiedades.getSelectedRow());
        t.setVisible(rootPaneCheckingEnabled);
        dispose();
    }//GEN-LAST:event_btnTratoActionPerformed

    private void jtPropiedadesMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jtPropiedadesMouseClicked
        btnTrato.setVisible(rootPaneCheckingEnabled);
    }//GEN-LAST:event_jtPropiedadesMouseClicked

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(ListarPropiedades.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(ListarPropiedades.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(ListarPropiedades.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(ListarPropiedades.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new ListarPropiedades().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnRegresar;
    private javax.swing.JButton btnTrato;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jtPropiedades;
    // End of variables declaration//GEN-END:variables
}
